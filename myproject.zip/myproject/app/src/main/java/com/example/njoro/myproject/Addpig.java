package com.example.njoro.myproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Addpig extends AppCompatActivity {

    private android.widget.EditText id, sex, age, weight, breedtype, color;
    private android.widget.Button savebut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addpig);

        id = findViewById(R.id.pigidedittext);
        sex = findViewById(R.id.pigsexeditText);
        age = findViewById(R.id.pigweighteditText);
        weight = findViewById(R.id.pigageeditText);
        breedtype= findViewById(R.id.pigbreedtypeeditText);
        color = findViewById(R.id.pigcoloreditText);
        savebut= findViewById(R.id.saverecordbutton);

    }
}
