package com.example.njoro.myproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }
    public void addpigbut(View view)
    {
        Intent njoro = new Intent(this, Addpig.class );
        startActivity(njoro);
        finish();
    }
    public void sowbut(View view)
    {
        Intent njoro = new Intent(this, Sow.class );
        startActivity(njoro);
        finish();
    }
    public void boarbut(View view)
    {
        Intent njoro = new Intent(this, Boar.class );
        startActivity(njoro);
        finish();
    }
    public void addexpensebut(View view)
    {
        Intent njoro = new Intent(this, Addexpense.class );
        startActivity(njoro);
        finish();
    }
    public void addsalesbut(View view)
    {
        Intent njoro = new Intent(this, Incomes.class );
        startActivity(njoro);
        finish();
    }
}
